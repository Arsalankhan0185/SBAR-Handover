CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE wards(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, type text, floor text);
CREATE TABLE beds(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), ward_id uuid REFERENCES wards, bed_no text NOT NULL,
  status text NOT NULL DEFAULT 'VACANT' CHECK (status IN ('VACANT','OCCUPIED','CLEANING','BLOCKED')), is_icu bool DEFAULT false);
CREATE TABLE users(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL, email text UNIQUE NOT NULL, password_hash text NOT NULL,
  role text NOT NULL CHECK (role IN ('NURSE','SUPERVISOR','DOCTOR','ADMIN')), license_no text, active bool DEFAULT true);
CREATE TABLE user_wards(user_id uuid REFERENCES users, ward_id uuid REFERENCES wards, PRIMARY KEY(user_id, ward_id));

CREATE TABLE patients(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), uhid text UNIQUE NOT NULL, abha_id text, name text NOT NULL,
  dob date, gender text, phone text);
CREATE TABLE admissions(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), patient_id uuid REFERENCES patients, bed_id uuid REFERENCES beds,
  admitting_doctor_id uuid REFERENCES users, admitted_at timestamptz DEFAULT now(), discharged_at timestamptz, diagnosis text,
  acuity text DEFAULT 'GREEN' CHECK (acuity IN ('RED','YELLOW','GREEN')), code_status text);
CREATE TABLE allergies(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), patient_id uuid REFERENCES patients, substance text, reaction text, severity text);
CREATE TABLE medical_history(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), patient_id uuid REFERENCES patients, condition text, notes text, since date);
CREATE TABLE medications(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), admission_id uuid REFERENCES admissions, drug text, dose text, route text,
  frequency text, start_at timestamptz, stop_at timestamptz, ordered_by uuid REFERENCES users);
CREATE TABLE medication_administrations(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), medication_id uuid REFERENCES medications,
  given_by uuid REFERENCES users, given_at timestamptz DEFAULT now(), status text CHECK (status IN ('GIVEN','HELD','REFUSED')), note text);

-- Append-only clinical data
CREATE TABLE vitals(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), admission_id uuid REFERENCES admissions NOT NULL,
  recorded_at timestamptz DEFAULT now(), recorded_by uuid REFERENCES users, sys_bp int, dia_bp int, pulse int, spo2 numeric, temp_c numeric,
  resp_rate int, grbs numeric, ecg_status text, gcs int, news2_score int, client_uuid uuid UNIQUE);
CREATE TABLE intake_output(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), admission_id uuid REFERENCES admissions, recorded_at timestamptz DEFAULT now(),
  recorded_by uuid REFERENCES users, category text CHECK (category IN ('IV_FLUID','ORAL','URINE','DRAIN')), direction text CHECK (direction IN ('IN','OUT')),
  volume_ml int, note text, client_uuid uuid UNIQUE);
CREATE TABLE investigations(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), admission_id uuid REFERENCES admissions, type text CHECK (type IN ('LAB','XRAY','CT','MRI')),
  name text, status text DEFAULT 'ORDERED' CHECK (status IN ('ORDERED','PENDING','REPORTED')), ordered_at timestamptz DEFAULT now(), reported_at timestamptz,
  result_summary text, file_url text);

-- Handover
CREATE TABLE shifts(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), ward_id uuid REFERENCES wards, type text CHECK (type IN ('MORNING','EVENING','NIGHT')), starts_at timestamptz, ends_at timestamptz);
CREATE TABLE shift_assignments(shift_id uuid REFERENCES shifts, nurse_id uuid REFERENCES users, admission_id uuid REFERENCES admissions, PRIMARY KEY(shift_id, nurse_id, admission_id));
CREATE TABLE handovers(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), shift_id uuid REFERENCES shifts, outgoing_nurse_id uuid REFERENCES users,
  incoming_nurse_id uuid REFERENCES users, ward_notes text, status text DEFAULT 'DRAFT' CHECK (status IN ('DRAFT','SIGNED')), signed_at timestamptz);
CREATE TABLE handover_patient_notes(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), handover_id uuid REFERENCES handovers, admission_id uuid REFERENCES admissions,
  situation text, background text, assessment text, recommendation text, pending_labs text, planned_procedures text, version int DEFAULT 1);
CREATE TABLE checklist_items(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), handover_id uuid REFERENCES handovers, admission_id uuid REFERENCES admissions,
  item text CHECK (item IN ('MEDS_GIVEN','DRESSING','CATHETER','IV_LINE')), done bool DEFAULT false, done_by uuid REFERENCES users, done_at timestamptz);
CREATE TABLE tasks(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), admission_id uuid REFERENCES admissions, text text NOT NULL, due_at timestamptz,
  done bool DEFAULT false, done_by uuid REFERENCES users);

-- Hospital & ward
CREATE TABLE equipment(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), ward_id uuid REFERENCES wards,
  type text CHECK (type IN ('CRASH_CART','VENTILATOR','INFUSION_PUMP','O2_CYLINDER')), asset_tag text,
  status text DEFAULT 'AVAILABLE' CHECK (status IN ('AVAILABLE','IN_USE','MAINTENANCE')), last_checked_at timestamptz, checked_by uuid REFERENCES users);
CREATE TABLE roster(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), ward_id uuid REFERENCES wards, user_id uuid REFERENCES users,
  shift_type text, duty_date date, role_on_duty text, on_call bool DEFAULT false);
CREATE TABLE sos_alerts(id uuid PRIMARY KEY DEFAULT gen_random_uuid(), ward_id uuid REFERENCES wards, admission_id uuid REFERENCES admissions,
  type text CHECK (type IN ('CODE_BLUE','DETERIORATION')), raised_by uuid REFERENCES users, raised_at timestamptz DEFAULT now(),
  acknowledged_by uuid REFERENCES users, acknowledged_at timestamptz, resolved_at timestamptz);
CREATE TABLE audit_log(id bigserial PRIMARY KEY, user_id uuid, action text, entity text, entity_id text, at timestamptz DEFAULT now(), ip inet);

CREATE VIEW bed_summary AS SELECT ward_id, count(*) total, count(*) FILTER (WHERE status='OCCUPIED') occupied,
  count(*) FILTER (WHERE status='VACANT') vacant, count(*) FILTER (WHERE is_icu AND status='VACANT') icu_vacant FROM beds GROUP BY ward_id;
CREATE INDEX ON vitals(admission_id, recorded_at DESC);
CREATE INDEX ON admissions(bed_id) WHERE discharged_at IS NULL;
