import http from 'http';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import pg from 'pg';
import { Server } from 'socket.io';

const { DATABASE_URL, JWT_SECRET, CORS_ORIGIN = 'http://localhost:8080', PORT = 3000 } = process.env;
if (!DATABASE_URL || !JWT_SECRET || JWT_SECRET.length < 32) throw new Error('Set DATABASE_URL and a JWT_SECRET of 32+ chars');

const db = new pg.Pool({ connectionString: DATABASE_URL });
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: CORS_ORIGIN } });
app.use(helmet(), cors({ origin: CORS_ORIGIN }), express.json({ limit: '100kb' }));

const wrap = fn => (req, res) => fn(req, res).catch(e => { console.error(e); res.status(500).json({ error: 'server error' }); });
const audit = (u, action, entity, id, ip) =>
  db.query('INSERT INTO audit_log(user_id,action,entity,entity_id,ip) VALUES($1,$2,$3,$4,$5)', [u, action, entity, id, ip]).catch(console.error);

// Auth
app.post('/auth/login', wrap(async (req, res) => {
  const { email, password } = req.body;
  const { rows: [u] } = await db.query('SELECT * FROM users WHERE email=$1 AND active', [email]);
  if (!u || !(await bcrypt.compare(password || '', u.password_hash))) return res.status(401).json({ error: 'invalid credentials' });
  const { rows: w } = await db.query('SELECT ward_id FROM user_wards WHERE user_id=$1', [u.id]);
  const token = jwt.sign({ sub: u.id, role: u.role, wards: w.map(x => x.ward_id) }, JWT_SECRET, { expiresIn: '8h' });
  audit(u.id, 'LOGIN', 'user', u.id, req.ip);
  res.json({ token, user: { id: u.id, name: u.name, role: u.role } });
}));

const auth = (req, res, next) => {
  try { req.user = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), JWT_SECRET); next(); }
  catch { res.status(401).json({ error: 'unauthorized' }); }
};
const ward = (req, res, next) => (req.user.wards.includes(req.params.wardId) || req.user.role === 'ADMIN') ? next() : res.status(403).json({ error: 'ward access denied' });

// Patients on a ward (current admissions + latest vitals)
app.get('/wards/:wardId/patients', auth, ward, wrap(async (req, res) => {
  const { rows } = await db.query(`
    SELECT a.id admission_id, p.name, p.uhid, p.gender, p.dob, b.bed_no, a.diagnosis, a.acuity,
      (SELECT row_to_json(v) FROM vitals v WHERE v.admission_id=a.id ORDER BY recorded_at DESC LIMIT 1) latest_vitals,
      (SELECT count(*) FROM tasks t WHERE t.admission_id=a.id AND NOT t.done) pending_tasks
    FROM admissions a JOIN patients p ON p.id=a.patient_id JOIN beds b ON b.id=a.bed_id
    WHERE b.ward_id=$1 AND a.discharged_at IS NULL
    ORDER BY CASE a.acuity WHEN 'RED' THEN 0 WHEN 'YELLOW' THEN 1 ELSE 2 END, b.bed_no`, [req.params.wardId]);
  audit(req.user.sub, 'VIEW_WARD', 'ward', req.params.wardId, req.ip);
  res.json(rows);
}));

// Record vitals (idempotent via client_uuid so offline retries never duplicate) -> broadcast
app.post('/wards/:wardId/vitals', auth, ward, wrap(async (req, res) => {
  const v = req.body;
  const { rows: [row] } = await db.query(
    `INSERT INTO vitals(admission_id,recorded_by,sys_bp,dia_bp,pulse,spo2,temp_c,resp_rate,grbs,ecg_status,gcs,client_uuid)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT (client_uuid) DO NOTHING RETURNING *`,
    [v.admission_id, req.user.sub, v.sys_bp, v.dia_bp, v.pulse, v.spo2, v.temp_c, v.resp_rate, v.grbs, v.ecg_status, v.gcs, v.client_uuid]);
  if (row) { io.to('ward:' + req.params.wardId).emit('vitals:new', row); audit(req.user.sub, 'ADD_VITALS', 'admission', v.admission_id, req.ip); }
  res.status(row ? 201 : 200).json(row || { duplicate: true });
}));

// Emergency SOS: persist, then push to everyone on the ward immediately (no patient name in payload)
app.post('/wards/:wardId/sos', auth, ward, wrap(async (req, res) => {
  const { type = 'CODE_BLUE', admission_id = null } = req.body;
  const { rows: [s] } = await db.query('INSERT INTO sos_alerts(ward_id,admission_id,type,raised_by) VALUES($1,$2,$3,$4) RETURNING id,type,raised_at',
    [req.params.wardId, admission_id, type, req.user.sub]);
  io.to('ward:' + req.params.wardId).emit('sos', { ...s, ward_id: req.params.wardId });
  audit(req.user.sub, 'SOS_' + type, 'ward', req.params.wardId, req.ip);
  res.status(201).json(s);
}));
app.post('/sos/:id/ack', auth, wrap(async (req, res) => {
  const { rows: [s] } = await db.query('UPDATE sos_alerts SET acknowledged_by=$1, acknowledged_at=now() WHERE id=$2 AND acknowledged_at IS NULL RETURNING ward_id,id',
    [req.user.sub, req.params.id]);
  if (s) io.to('ward:' + s.ward_id).emit('sos:ack', s);
  res.json(s || { already: true });
}));

// Sign handover
app.post('/handovers/:id/sign', auth, wrap(async (req, res) => {
  const { rowCount } = await db.query("UPDATE handovers SET status='SIGNED', signed_at=now() WHERE id=$1 AND status='DRAFT'", [req.params.id]);
  audit(req.user.sub, 'SIGN_HANDOVER', 'handover', req.params.id, req.ip);
  res.json({ signed: rowCount === 1 });
}));

app.get('/health', (_q, r) => r.json({ ok: true }));

// Realtime: each socket joins only the wards its token allows
io.use((s, next) => { try { s.user = jwt.verify(s.handshake.auth.token, JWT_SECRET); next(); } catch { next(new Error('unauthorized')); } });
io.on('connection', s => s.user.wards.forEach(w => s.join('ward:' + w)));

server.listen(PORT, () => console.log('API on :' + PORT));
