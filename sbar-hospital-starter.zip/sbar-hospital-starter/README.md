# SBAR Handover - Hospital Nursing App (starter)

- `web/`  Installable PWA (Android/iOS/desktop). Currently the offline prototype (data in browser). Next step: call the API + Socket.IO.
- `api/`  Node/Express + Socket.IO + PostgreSQL. JWT auth, ward-scoped access, audit log, idempotent vitals, realtime ward channels, SOS.
- `db/schema.sql`  Full schema: patients, vitals, I/O, labs, handover, checklist, equipment, roster, SOS, audit.

## Run locally
    cp .env.example .env       # edit secrets
    docker compose up --build  # API on :3000, DB created from db/schema.sql

Create the first user (hash a password with bcryptjs, e.g. `cd api && npm i && node -e "import('bcryptjs').then(b=>console.log(b.default.hashSync('YourPassword',12)))"`):
    INSERT INTO users(name,email,password_hash,role) VALUES('Admin','you@x.com','<hash>','ADMIN');

## Realtime (client)
    const s = io(API_URL, { auth: { token } });
    s.on('vitals:new', v => updateBoard(v));
    s.on('sos', a => showCodeBlue(a));

## Deploy
- `web/` -> GitHub Pages (workflow included; Settings > Pages > Source: GitHub Actions).
- `api/` + Postgres -> Render / Fly.io / AWS / Azure (needs HTTPS). GitHub Pages cannot run the API.

## Before real patient data
Not compliance-certified. You still need MFA, TLS, encryption at rest, backups, hosting BAA / DPDP terms, a security review and hospital approval.
Keep the repo private; never commit .env or patient data.
