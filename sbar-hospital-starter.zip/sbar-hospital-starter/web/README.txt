SBAR Shift Handover - installable app (PWA) - full version

1. Upload this whole folder to any HTTPS host (GitHub Pages, Netlify Drop, Cloudflare Pages, Firebase Hosting).
2. Open the link on your phone:
   - Android Chrome: menu > Install app / Add to Home screen
   - iPhone Safari: Share > Add to Home Screen
3. After the first online load it works offline; patient data is saved on the device.

Features: ward dashboard, acuity filters + search, SBAR editing, editable vitals,
acuity change, ward transfer, task checklist, add/discharge patient,
shift sign-off with saved history + printable report, backup/restore (JSON).
